#!/usr/bin/env python3 
import csv
import sys
import matplotlib.pyplot as plt
from collections import defaultdict
from textwrap import wrap
import numpy as np

plt.style.use('classic')

plt.rcParams['pdf.fonttype'] = 42

def myplot(cg, maxD):
    input = f'expdata/tods23/latest/cuboid-distr_{cg}.csv'
    series={}
    with open(input) as fh:
        header = [h.strip() for h in fh.readline().split(',')]
        reader = csv.DictReader(fh, fieldnames=header)
        data = list(reader)
        for row in data:
            key = row['Series'] #includes 'total' as well
            distr = [(k, float(row[str(k)])) for k in range(0, maxD+1) if float(row[str(k)]) > 0]
            # print(distr)
            series[key]=distr

    fig, ax = plt.subplots(figsize=(4,5))
    ax.grid(which='major', axis='y',linestyle='dotted',zorder=0)

    for s in series.items():
        X = list(map(lambda kv: kv[0], s[1]))
        Y = list(map(lambda kv: kv[1], s[1]))
        if(s[0]=='Total Random'):
            ax.plot(X, Y, label='Total Uniform', color='black', ls='dotted')
        elif(s[0]=='Total Prefix'):
            ax.plot(X, Y, label='Total Prefix', color='black', ls='dashed')
        else:
            ax.plot(X, Y, label='$' + s[0].replace('n=', 'N=').replace('}\\', '},\\') + '$')

    ax.legend(loc='center left', fontsize=11, bbox_to_anchor=(1,0.5), labelspacing=1.5)
    ax.set_xlabel('Cuboid Dimensionality')
    ax.set_ylabel('Number of Cuboids')
    ax.set_ylim(top=2**56, bottom=1)
    ax.set_xlim(left=0,right=maxD)
    plt.xticks(np.arange(0, maxD+1, 4.0))
    ax.set_yscale('log',base=2)
    plt.savefig(f'figs/tods23/cuboid-distr_{cg}.pdf',bbox_inches = 'tight',pad_inches = 0.01)


myplot('SSB-sf100', 30)