#!/usr/bin/env python3 


import csv
import matplotlib.pyplot as plt
from collections import defaultdict
import numpy as np

plt.style.use('classic')
fig, ((ax1,ax2)) = plt.subplots(2,1,figsize = (6,6))
ax1.grid(which='major', axis='y',linestyle='dotted',zorder=0)
ax2.grid(which='major', axis='y',linestyle='dotted',zorder=0)

lines=[]
def mean(x):
	return sum(x) / len(x)

def plot(cubeGenerator, cgstring, MS, MSstring, ax):
	input = f'expdata/tods23/latest/all-solvers_{cubeGenerator}-{MS}-qsize.csv'
	filename = input[8:-4]
	print(filename)
	timescale = 1000.0 * 1000.0
	timeLP = defaultdict(lambda : [])
	timeIPF = defaultdict(lambda : [])
	timeMoment = defaultdict(lambda : [])
	timeNaive = defaultdict(lambda : [])
	title = f"{cgstring} {MSstring}"

	with open(input) as fh:
		header = [h.strip() for h in fh.readline().split(',')]
		reader = csv.DictReader(fh, fieldnames=header)
		data = list(reader)
		for row in data:

			key = int(row['QSize'])
			if(key <= 10):
				timeLP[key].append(float(row['TotalLP'])/timescale)
			timeIPF[key].append(float(row['TotalIPF'])/timescale)
			timeMoment[key].append(float(row['TotalMoment'])/timescale)
			timeNaive[key].append(float(row['TotalNaive'])/timescale)

	def plotSeries(series, l, c):
		X = np.array(sorted(series.keys()))
		Y = np.array(list(map(lambda x: mean(x[1]), sorted(series.items(),key = lambda kv: kv[0]))))
		ax.plot(X, Y, label=l, zorder=3, c=c)

	ax.title.set_text(title)
	ax.set_xlabel('Query dimensionality $q$')
	ax.set_ylabel('Time(s)')
	ax.set_yscale('log',)
	ax.set_ylim(top=3, bottom=10**-2)

	plotSeries(timeLP, 'Linear Programming', 'm')
	plotSeries(timeMoment, 'Moment', 'g')
	plotSeries(timeIPF, 'IPF', 'r')
	plotSeries(timeNaive, 'Naive', 'b')



plot('NYC', 'NYC', 'false', 'Uniform', ax1)
plot('NYC', 'NYC', 'true', 'Prefix', ax2)

plt.subplots_adjust(hspace=0.6, wspace=0.2)

handles, labels = ax1.get_legend_handles_labels()
lgd=fig.legend(handles, labels, ncol=2, loc='upper center', fontsize=12, bbox_to_anchor=(0.5,-0.01), columnspacing=2)
plt.savefig('figs/tods23/allsolver-time-qsize.pdf', bbox_extra_artists=[lgd], bbox_inches = 'tight', pad_inches=0.01)
#plt.show()