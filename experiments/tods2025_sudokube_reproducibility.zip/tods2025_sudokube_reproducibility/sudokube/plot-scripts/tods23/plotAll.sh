ROOT=plot-scripts/tods23

#Figure 11
python3 $ROOT/cube-stats.py
#Table 3
python3 $ROOT/cuboid-distr.py

#Figure 12a
python3 $ROOT/naive-hist-qsize.py
#Figure 12b
python3 $ROOT/fetch-qsize.py

#Figure 13abc
python3 $ROOT/allsolver-time-qsize.py
python3 $ROOT/allsolver-err-qsize.py
python3 $ROOT/allsolver-online-qsize.py

#Figure 14abc
python3 $ROOT/manual-online-qsize.py
python3 $ROOT/manual-online-solver.py
python3 $ROOT/manual-online-matparam.py

#Figure 15abc
python3 $ROOT/ipf-time-qsize.py
python3 $ROOT/ipf-errhist-qsize.py
python3 $ROOT/naiveXipf-time-qsize.py





