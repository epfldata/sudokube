#!/usr/bin/env python3

import csv
import matplotlib.pyplot as plt
from collections import defaultdict
import numpy as np


def nextKey(dic, var):
    k2 = min([k for k in dic if k > var], default=float('inf'))
    return k2

def prevValue(dic, var, init):
    k2 = max([k for k in dic.keys() if k <= var], default=None)
    return dic.get(k2, init)

def plotExtrapolate(series, initY, ax, l, color):
    numRuns = len(series)
    curX = 0.0
    curY = initY
    epsilon = 10**-9
    X=[]
    Y=[]
    while (curX < float('inf')):
        X.append(curX)
        Y.append(curY)
        nextX = min([nextKey(series[r], curX) for r in series.keys()])
        nextY = sum([prevValue(series[r], nextX, initY) for r in series.keys()])/numRuns
        X.append(nextX-epsilon)
        Y.append(curY)
        curX = nextX
        curY = nextY
    ax.plot(X, Y, label=l, color=color)

plt.style.use('classic')
fig, ((ax1,ax2)) = plt.subplots(2,1,figsize = (6,6))
ax1.grid(which='major', axis='y',linestyle='dotted',zorder=0)
ax2.grid(which='major', axis='y',linestyle='dotted',zorder=0)


def plot(cubeGenerator, cgstring, MS, MSstring, ax):
    input = f'expdata/tods23/latest/all-solvers-online_{cubeGenerator}-{MS}.csv'
    filename = input[8:-4]
    print(filename)
    series = defaultdict(lambda : defaultdict(lambda : {}))
    title = f"{cgstring} {MSstring}"

    with open(input) as fh:
        header = [h.strip() for h in fh.readline().split(',')]
        reader = csv.DictReader(fh, fieldnames=header)
        data = list(reader)
        for row in data:
            key = row['SolverName']
            runid = int(row['RunID'])
            x = float(row['StatTime'])
            y = float(row['Error'])
            series[key][runid][x] = y

    for (s, c) in [('Naive', 'b'),  ('Moment (with fix)', 'darkgreen'), ('IPF', 'r'), ('Moment (no fix)', 'limegreen')]:
        plotExtrapolate(series[s], 1.0, ax, f'{s}', c)

    ax.title.set_text(title)
    ax.set_xlabel('Time(s)')
    ax.set_ylabel('Error')
    ax.set_xscale('log')
    ax.set_xlim(left=0.01)
    ax.locator_params(axis='y', nbins=7)

plot('NYC', 'NYC', 'false', 'Uniform', ax1)
plot('NYC', 'NYC', 'true', 'Prefix', ax2)

plt.subplots_adjust(hspace=0.4)

handles, labels = ax1.get_legend_handles_labels()
lgd=fig.legend(handles, labels, ncol=2, loc='upper center', fontsize=14, bbox_to_anchor=(0.5,-0.01), columnspacing=2)
plt.savefig('figs/tods23/allsolver-online.pdf', bbox_extra_artists=[lgd], bbox_inches = 'tight', pad_inches=0.01)
# plt.show()