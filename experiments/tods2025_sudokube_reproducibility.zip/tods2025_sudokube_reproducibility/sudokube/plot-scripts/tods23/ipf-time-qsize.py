#!/usr/bin/env python3 


import csv
import matplotlib.pyplot as plt
from collections import defaultdict
import numpy as np

plt.style.use('classic')
fig, ((ax1,ax2)) = plt.subplots(2,1,figsize = (6,6))
ax1.grid(which='major', axis='y',linestyle='dotted',zorder=0)
ax2.grid(which='major', axis='y',linestyle='dotted',zorder=0)

def mean(x):
	return sum(x) / len(x)

def plot(cubeGenerator, cgstring, MS, MSstring, handleNegative, ax):
	input = f'expdata/tods23/latest/ipf-batch_{cubeGenerator}-{MS}-qsize.csv'
	filename = input[8:-4]
	print(filename)

	prepare = defaultdict(lambda: [])
	fetch = defaultdict(lambda: [])
	solvevanilla = defaultdict(lambda: [])
	solvejunction = defaultdict(lambda: [])
	solvemoment = defaultdict(lambda: [])
	solvemst = defaultdict(lambda: [])
	title = f"{cgstring} {MSstring}"

	with open(input) as fh:
		header = [h.strip() for h in fh.readline().split(',')]
		reader = csv.DictReader(fh, fieldnames=header)
		data = list(reader)
		timescale=1000.0 * 1000.0
		for row in data:
			key = int(row['QSize'])
			prepareTime = float(row['PrepareTime(us)'])/timescale
			fetchTime = float(row['FetchTime(us)'])/timescale
			solveTimeVanilla = float(row['SolveTimeVanilla(us)'])/timescale
			solveTimeJunction = float(row['SolveTimeJunction(us)'])/timescale
			solveTimeMoment = float(row['SolveTimeMomentIPF(us)'])/timescale
			solveTimeMST= float(row['SolveTimeMST(us)'])/timescale

			prepare[key].append(prepareTime)
			fetch[key].append(fetchTime)
			solvevanilla[key].append(solveTimeVanilla)
			solvejunction[key].append(solveTimeJunction)
			solvemoment[key].append(solveTimeMoment)
			solvemst[key].append(solveTimeMST)



	keys = np.array(sorted(prepare.keys()))
	prepareAvg = np.array(list(map(lambda x: mean(x[1]), sorted(prepare.items(),key = lambda kv: kv[0]))))
	fetchAvg = np.array(list(map(lambda x: mean(x[1]), sorted(fetch.items(),key = lambda kv: kv[0]))))
	vanillaAvg = np.array(list(map(lambda x: mean(x[1]), sorted(solvevanilla.items(),key = lambda kv: kv[0]))))
	junctionAvg = np.array(list(map(lambda x: mean(x[1]), sorted(solvejunction.items(),key = lambda kv: kv[0]))))
	momentAvg = np.array(list(map(lambda x: mean(x[1]), sorted(solvemoment.items(),key = lambda kv: kv[0]))))
	mstAvg = np.array(list(map(lambda x: mean(x[1]), sorted(solvemst.items(),key = lambda kv: kv[0]))))



	ax.plot(keys, prepareAvg, label="Prepare",ls='dashed', c='red', zorder=3)
	ax.plot(keys, fetchAvg, label="Fetch",ls='dashed', c='magenta', zorder=3)
	ax.plot(keys, vanillaAvg, label='Solve Vanilla IPF', c='sandybrown', zorder=3)
	ax.plot(keys, junctionAvg, label='Solve JunctionTree IPF', c='lightskyblue', zorder=3)
	ax.plot(keys, momentAvg, label='Solve Moment IPF', c='green', zorder=3)
	ax.plot(keys, mstAvg, label='Solve MST IPF', c='blue', zorder=3)

	
	ax.title.set_text(title)
	ax.set_xlabel('Query dimensionality $q$')
	ax.set_ylabel('Time(s)')
	ax.set_yscale('log')
	#ax.set_xlabel('Error')



plot('SSB-sf100', 'SSB', 'false', 'Uniform', 'true', ax1)
plot('SSB-sf100', 'SSB', 'true', 'Prefix', 'true', ax2)

plt.subplots_adjust(hspace=0.6)

handles, labels = ax1.get_legend_handles_labels()
lgd=fig.legend(handles, labels, ncol=3, loc='upper center', fontsize=11, bbox_to_anchor=(0.5,-0.01), columnspacing=1)
plt.savefig('figs/tods23/ipf-time-qsize.pdf', bbox_extra_artists=[lgd], bbox_inches = 'tight', pad_inches=0.01)
#plt.show()