#!/usr/bin/env python3 


import csv
import matplotlib.pyplot as plt
from collections import defaultdict
import numpy as np

plt.style.use('classic')
fig, ((ax1,ax2)) = plt.subplots(2,1,figsize = (6,6))
ax1.grid(which='major', axis='y',linestyle='dotted',zorder=0)
ax2.grid(which='major', axis='y',linestyle='dotted',zorder=0)

lines=[]
def mean(x):
	return sum(x) / len(x)

def plot(cubeGenerator, cgstring, MS, MSstring, ax):
	input = f'expdata/tods23/latest/all-solvers_{cubeGenerator}-{MS}-qsize.csv'
	filename = input[8:-4]
	print(filename)

	spanLP = defaultdict(lambda : [])
	errLP = defaultdict(lambda : [])
	errIPF = defaultdict(lambda : [])
	errMoment = defaultdict(lambda : [])
	errMoment2 = defaultdict(lambda : [])
	title = f"{cgstring} {MSstring}"

	with open(input) as fh:
		header = [h.strip() for h in fh.readline().split(',')]
		reader = csv.DictReader(fh, fieldnames=header)
		data = list(reader)
		for row in data:

			key = int(row['QSize'])
			if(key <= 10):
				errLP[key].append(float(row['MidpointErrorLP']))
				spanLP[key].append(float(row['ErrorLP']))
			errIPF[key].append(float(row['ErrorIPF']))
			errMoment[key].append(float(row['ErrorMoment']))
			errMoment2[key].append(float(row['ErrorMoment2']))

	def plotSeries(series, l, axis, c):
		X = np.array(sorted(series.keys()))
		Y = np.array(list(map(lambda x: mean(x[1]), sorted(series.items(),key = lambda kv: kv[0]))))
		axis.plot(X, Y, label=l, zorder=3, c=c)

	# az = ax.twinx()
	ax.title.set_text(title)
	ax.set_xlabel('Query dimensionality $q$')
	ax.set_ylabel('Error')
	ax.set_yscale('log',)
	# az.set_ylabel('Span')
	# az.set_yscale('log')
	ax.locator_params(axis='y', numticks=8)

	plotSeries(errLP, 'Linear Programming', ax, 'm')
	plotSeries(errMoment, 'Moment (with fix)', ax, 'darkgreen')
	plotSeries(errIPF, 'IPF', ax, 'red')
	plotSeries(errMoment2, 'Moment (no fix)', ax, 'limegreen')

	# plotSeries(spanLP, 'LP Span', az)


plot('NYC', 'NYC', 'false', 'Uniform', ax1)
plot('NYC', 'NYC', 'true', 'Prefix', ax2)

plt.subplots_adjust(hspace=0.4, wspace=0.2)

handles, labels = ax1.get_legend_handles_labels()
lgd=fig.legend(handles, labels, ncol=2, loc='upper center', fontsize=12, bbox_to_anchor=(0.5,-0.01), columnspacing=2)
plt.savefig('figs/tods23/allsolver-error-qsize.pdf', bbox_extra_artists=[lgd], bbox_inches = 'tight', pad_inches=0.01)
# plt.show()