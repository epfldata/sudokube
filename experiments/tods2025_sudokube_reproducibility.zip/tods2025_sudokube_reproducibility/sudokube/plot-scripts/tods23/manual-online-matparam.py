#!/usr/bin/env python3

import csv
import matplotlib.pyplot as plt
from collections import defaultdict
import numpy as np


def nextKey(dic, var):
    k2 = min([k for k in dic if k > var], default=float('inf'))
    return k2

def prevValue(dic, var, init):
    k2 = max([k for k in dic.keys() if k <= var], default=None)
    return dic.get(k2, init)

def plotExtrapolate(series, initY, ax, l):
    numRuns = len(series)
    curX = 0.0
    curY = initY
    epsilon = 10**-9
    X=[]
    Y=[]
    while (curX < float('inf')):
        X.append(curX)
        Y.append(curY)
        nextX = min([nextKey(series[r], curX) for r in series.keys()])
        nextY = sum([prevValue(series[r], nextX, initY) for r in series.keys()])/numRuns
        X.append(nextX-epsilon)
        Y.append(curY)
        curX = nextX
        curY = nextY
    ax.plot(X, Y, label=l)

plt.style.use('classic')
fig, ((ax1,ax2)) = plt.subplots(2,1,figsize = (6,6))
ax1.grid(which='major', axis='y',linestyle='dotted',zorder=0)
ax2.grid(which='major', axis='y',linestyle='dotted',zorder=0)

lgd=[]
def plot(cubeGenerator, cgstring, MS, MSstring, ax):
    global lgd
    input = f'expdata/tods23/latest/all-solvers-online_{cubeGenerator}-{MS}-manual-matparams.csv'
    filename = input[8:-4]
    print(filename)
    series = defaultdict(lambda : defaultdict(lambda : {}))
    title = f"{cgstring} {MSstring}"

    with open(input) as fh:
        header = [h.strip() for h in fh.readline().split(',')]
        reader = csv.DictReader(fh, fieldnames=header)
        data = list(reader)
        for row in data:
            query = row['QName']
            qs = int(row['QSize'])
            fullname = row['CubeName'].split('_')

            key = (fullname[2], fullname[3])
            runid = int(row['RunID'])
            x = float(row['StatTime'])
            y = float(row['Error'])
            series[key][runid][x] = y

    for s in series.keys():
        plotExtrapolate(series[s], 1.0, ax, '$N=2^{' + str(s[0]) +'}\ d_\\min=' + str(s[1])+'$')

    ax.title.set_text(title)
    ax.set_xlabel('Time(s)')
    ax.set_ylabel('Error')
    ax.set_xscale('log')
    # ax.set_yscale('log')
    ax.set_xlim(left=0.01)
    ax.set_ylim(top=0.15)
    ax.locator_params(axis='y', nbins=7)
    lgd.append(ax.legend(ncol=3, loc='upper center', fontsize=11, bbox_to_anchor=(0.465, -0.25), columnspacing=1))
plot('SSB-sf100', 'SSB', 'true', 'Prefix', ax1)
plot('NYC', 'NYC', 'true', 'Prefix', ax2)

plt.subplots_adjust(hspace=0.8, bottom=0.1)

plt.savefig('figs/tods23/allsolver-online-manual-matparam.pdf', bbox_extra_artists=lgd, bbox_inches = 'tight', pad_inches=0.01)
# plt.show()