#!/usr/bin/env python3 


import csv
import matplotlib.pyplot as plt
from collections import defaultdict
import numpy as np

plt.style.use('classic')

def mean(x):
	return sum(x) / len(x)

def plotAll():
	fig, ((ax1,ax2), (ax3, ax4)) = plt.subplots(2,2,figsize = (12,6))
	ax1.grid(which='major', axis='y',linestyle='dotted',zorder=0)
	ax2.grid(which='major', axis='y',linestyle='dotted',zorder=0)
	ax3.grid(which='major', axis='y',linestyle='dotted',zorder=0)
	ax4.grid(which='major', axis='y',linestyle='dotted',zorder=0)


	def plot(column, cubeGenerator, cgstring, MS, MSstring, ax):
		input = f'expdata/tods23/latest/fetch-batch_{cubeGenerator}-{MS}-qsize.csv'
		filename = input[8:-4]
		print(filename)
		minX=30
		maxX=0
		series = defaultdict(lambda: defaultdict(lambda: []))
		title = f"{cgstring} {MSstring}"

		with open(input) as fh:
			header = [h.strip() for h in fh.readline().split(',')]
			reader = csv.DictReader(fh, fieldnames=header)
			data = list(reader)
			for row in data:
				key = int(row['QSize'])
				x= int(row['CuboidDim'])
				y=int(row[column])
				if(key <= 12):
					if(y > 0):
						minX = min(x, minX)
						maxX = max(x, maxX)
					series[key][x].append(y)

		w=1.0/(len(series)+1)
		i=0.5-int(len(series)/2)
		for s in sorted(series.keys()):
			keys = np.array(sorted(series[s].keys()))
			seriesAvg = np.array(list(map(lambda x: mean(x[1]), sorted(series[s].items(),key = lambda kv: kv[0]))))
			ax.bar(keys+(i*w), seriesAvg, label=s, zorder=3, width=w)
			i += 1
		print(f'minX={minX} maxX={maxX}')
		if (maxX > 25):
			maxX = 25
		ax.title.set_text(title)
		before = 'before'  if column == 'SrcCuboidCount' else 'after'
		ax.set_xlabel(f'Cuboid dimensionality {before} projection')
		ax.set_ylabel('Average frequency')

		ax.set_xticks(np.arange(0, 40, 1))
		ax.set_xlim(left=minX-0.5,right=maxX + 0.5)


		#ax.set_xlabel('Error')




	plot('SrcCuboidCount', 'NYC', 'NYC', 'false', 'Uniform', ax1)
	plot('SrcCuboidCount', 'NYC', 'NYC', 'true', 'Prefix', ax3)
	plot('DstCuboidCount', 'NYC', 'NYC', 'false', 'Uniform', ax2)
	plot('DstCuboidCount', 'NYC', 'NYC', 'true', 'Prefix', ax4)

	plt.subplots_adjust(wspace=0.143, hspace=0.6)

	handles, labels = ax1.get_legend_handles_labels()
	lgd=fig.legend(handles, labels, ncol=6, loc='upper center', fontsize=16, bbox_to_anchor=(0.5,-0.01), columnspacing=2)
	plt.savefig(f'figs/tods23/fetch-qsize.pdf', bbox_extra_artists=[lgd], bbox_inches = 'tight', pad_inches=0.01)
	# plt.show()
plotAll()