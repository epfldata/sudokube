#!/usr/bin/env python3 


import csv
import matplotlib.pyplot as plt
from collections import defaultdict
import numpy as np

plt.style.use('classic')
fig, ((ax1,ax2)) = plt.subplots(2,1,figsize = (6,6))
ax1.grid(which='major', axis='y',linestyle='dotted',zorder=0)
ax2.grid(which='major', axis='y',linestyle='dotted',zorder=0)

def mean(x):
	return sum(x) / len(x)

def plot(cubeGenerator, cgstring, MS, MSstring, handleNegative, ax):
	input = f'expdata/tods23/latest/all-solvers_{cubeGenerator}-{MS}-qsize.csv'
	filename = input[8:-4]
	print(filename)

	prepareIPF = defaultdict(lambda: [])
	fetchIPF = defaultdict(lambda: [])
	solveIPF = defaultdict(lambda: [])
	totalIPF = defaultdict(lambda : [])

	prepareNaive = defaultdict(lambda: [])
	fetchNaive = defaultdict(lambda: [])
	totalNaive = defaultdict(lambda : [])
	title = f"{cgstring} {MSstring}"

	with open(input) as fh:
		header = [h.strip() for h in fh.readline().split(',')]
		reader = csv.DictReader(fh, fieldnames=header)
		data = list(reader)
		timescale=1000.0 * 1000.0
		for row in data:
			key = int(row['QSize'])
			prepareNaiveTime = float(row['PrepareNaive'])/timescale
			fetchNaiveTime = float(row['FetchNaive'])/timescale
			totalNaiveTime = float(row['TotalNaive'])/timescale

			prepareIPFTime = float(row['PrepareIPF'])/timescale
			fetchIPFTime = float(row['FetchIPF'])/timescale
			solveIPFTime = float(row['SolveIPF'])/timescale
			totalIPFTime = float(row['TotalIPF'])/timescale

			prepareNaive[key].append(prepareNaiveTime)
			fetchNaive[key].append(fetchNaiveTime)
			totalNaive[key].append(totalNaiveTime)

			prepareIPF[key].append(prepareIPFTime)
			fetchIPF[key].append(fetchIPFTime)
			solveIPF[key].append(solveIPFTime)
			totalIPF[key].append(totalIPFTime)

	keys = np.array(sorted(prepareNaive.keys()))

	def plotAvg(data, label, style, color):
		dataAvg = np.array(list(map(lambda x: mean(x[1]), sorted(data.items(),key = lambda kv: kv[0]))))
		ax.plot(keys, dataAvg, label=label, ls=style, c=color, zorder=3)





	plotAvg(prepareIPF, "IPF Prepare", 'solid', 'red')
	plotAvg(prepareNaive, "Naive Prepare", 'dashed', 'tomato')

	plotAvg(fetchIPF, "IPF Fetch", 'solid', 'blue')
	plotAvg(fetchNaive, "Naive Fetch", 'dashed', 'skyblue')

	plotAvg(totalIPF, "IPF Total", 'solid', 'black')
	plotAvg(totalNaive, "Naive Total", 'dashed', 'gray')

	plotAvg(solveIPF, "IPF Solve", 'solid', 'green')
	ax.title.set_text(title)
	ax.set_xlabel('Query dimensionality $q$')
	ax.set_ylabel('Time(s)')
	ax.set_yscale('log')


plot('SSB-sf100', 'SSB', 'false', 'Uniform', 'true', ax1)
plot('SSB-sf100', 'SSB', 'true', 'Prefix', 'true', ax2)

plt.subplots_adjust(hspace=0.6)

handles, labels = ax1.get_legend_handles_labels()
lgd=fig.legend(handles, labels, ncol=4, loc='upper center', fontsize=11, bbox_to_anchor=(0.5,-0.01), columnspacing=1)
plt.savefig('figs/tods23/naiveXipf-time-qsize.pdf', bbox_extra_artists=[lgd], bbox_inches = 'tight', pad_inches=0.01)
#plt.show()