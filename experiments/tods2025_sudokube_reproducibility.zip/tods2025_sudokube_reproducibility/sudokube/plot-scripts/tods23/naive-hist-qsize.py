#!/usr/bin/env python3 


import csv
import matplotlib.pyplot as plt
from collections import defaultdict
import numpy as np

plt.style.use('classic')

def mean(x):
	return sum(x) / len(x)


fig, ((ax1,ax2)) = plt.subplots(2,1,figsize = (6,6))
ax1.grid(which='major', axis='y',linestyle='dotted',zorder=0)
ax2.grid(which='major', axis='y',linestyle='dotted',zorder=0)

def plot(cubeGenerator, cgstring, MS, MSstring, ax):
	input = f'expdata/tods23/latest/naive-solver_{cubeGenerator}-{MS}-qsize.csv'
	filename = input[8:-4]
	print(filename)
	allkeys = set()
	series = defaultdict(lambda: defaultdict(lambda : 0.0))
	count = defaultdict(lambda: 0.0)
	title = f"{cgstring} {MSstring}"

	with open(input) as fh:
		header = [h.strip() for h in fh.readline().split(',')]
		reader = csv.DictReader(fh, fieldnames=header)
		data = list(reader)
		for row in data:
			key = int(row['QSize'])
			x= int(row['SourceCuboidDim'])
			series[key][x] += 1.0
			count[key] += 1.0
			allkeys.add(x)

	sortedkeys = sorted(list(allkeys))
	X = np.arange(0, len(sortedkeys))
	w=1.0/(len(series)+1)
	i=0.5-int(len(series)/2)

	for s in sorted(series.keys()):
		seriesAvg = np.array([series[s][x]/count[s] for x in sortedkeys])
		ax.bar(X+(i*w), seriesAvg, label=s, zorder=3, width=w)
		i += 1

	ax.title.set_text(title)
	ax.set_xlabel('Cuboid dimensionality before projection')
	ax.set_ylabel('Average frequency')
	ax.set_xticks(X)
	ax.set_xticklabels(sortedkeys)
	ax.set_xlim(left=-0.5,right=len(X)-0.5)
	#ax.set_xlabel('Error')



plot('NYC', 'NYC', 'false', 'Uniform', ax1)
plot('NYC', 'NYC', 'true', 'Prefix', ax2)

plt.subplots_adjust(hspace=0.6)

handles, labels = ax1.get_legend_handles_labels()
lgd=fig.legend(handles, labels, ncol=8, loc='upper center', fontsize=12, bbox_to_anchor=(0.5,-0.01), columnspacing=1)
plt.savefig(f'figs/tods23/naive-hist-qsize.pdf', bbox_extra_artists=[lgd], bbox_inches = 'tight', pad_inches=0.01)
