import csv
from sys import stdout
from collections import defaultdict
sizeData = defaultdict(lambda: defaultdict(lambda : {}))
ratioData = defaultdict(lambda: defaultdict(lambda : {}))
def gen(cubeGenerator, cgstringorig, MS, MSstring, outfile, separator):
    input = f'expdata/tods23/latest/cube-stat_{cubeGenerator}-{MS}.csv'
    filename = input[8:-4]
    #print(filename)

    cgstring = '\\' + cgstringorig + '{}'
    with open(input) as fh:
        header = [h.strip() for h in fh.readline().split(',')]
        reader = csv.DictReader(fh, fieldnames=header)
        data = list(reader)
        for row in data:
            logN = int(row['logn'])
            mind = int(row['mind'])
            size = round(float(row['cuboidGB']), 3)
            ratio = round(float(row['ratio'])-1.0, 3)
            sizeData[cgstring][(logN, mind)][MS] = size
            ratioData[cgstring][(logN, mind)][MS] = ratio


with open('figs/tods23/cube-stats.tex', 'w') as outfile:
    gen('SSB-sf100', 'SSB', 'false', 'Random', outfile, '\\\\')
    gen('SSB-sf100', 'SSB', 'true', 'Prefix', outfile, '\\\\')
    gen('NYC', 'NYC', 'false', 'Random', outfile, '\\\\')
    gen('NYC', 'NYC', 'true', 'Prefix', outfile, '\\\\')

    for cg in sizeData.keys():
        for (params, values) in sizeData[cg].items():
            outfile.write(f'{cg} &  $2^' + '{' + str(params[0]) + '}$' + f' & {params[1]} & {values["false"]} & {ratioData[cg][params]["false"]} & {values["true"]} & {ratioData[cg][params]["true"]}\\\\\n')
