#!/usr/bin/env python3 


import csv
import matplotlib.pyplot as plt
from collections import defaultdict
import numpy as np

plt.style.use('classic')
fig, (ax1,ax2) = plt.subplots(2,1,figsize = (6,6))
ax1.grid(which='major', axis='y',linestyle='dotted',zorder=0)
ax1.grid(which='major', axis='x',linestyle='dotted',zorder=0)
ax2.grid(which='major', axis='y',linestyle='dotted',zorder=0)
ax2.grid(which='major', axis='x',linestyle='dotted',zorder=0)

lines=[]

def plot(cubeGenerator, cgstring, MS, MSstring, ax):
	input = f'expdata/tods23/latest/all-solvers_{cubeGenerator}-{MS}-qsize.csv'
	filename = input[8:-4]
	print(filename)
	errMoment = defaultdict(lambda : [])
	title = f"{cgstring} {MSstring}"

	with open(input) as fh:
		header = [h.strip() for h in fh.readline().split(',')]
		reader = csv.DictReader(fh, fieldnames=header)
		data = list(reader)
		for row in data:
			key = int(row['QSize'])
			if(key > 6 and key < 18):
				errMoment[key].append(float(row['ErrorIPF']))


	maxX = max(max(errMoment.values()))
	minY = 1.0
	for s in sorted(errMoment.items(), key=lambda kv: kv[0]):
		maxv = max(s[1])
		values, base = np.histogram(s[1], bins=20, range=(0.0, maxv+0.00001))
		total = sum(values)
		cumsum = np.cumsum(values)
		minYlocal = min(cumsum)/total

		if(minY > minYlocal):
			minY = minYlocal
		cumulative = map(lambda x: float(x)/total, np.insert(cumsum,0,0))
		ax.plot(list(base), list(cumulative), label=s[0],zorder=3, marker='s', ms=2)
	ax.set_ylabel('Fraction of Queries')
	# ax.locator_params(axis='y', nbins=12)
	ax.set_xlim([-maxX/12.0, maxX])
	# ax.set_xlim([10**-4, maxX])
	ax.set_ylim(bottom=minY-0.1, top=1.0)
	print(minY)
	ax.title.set_text(title)
	ax.set_xlabel('Error')
	# ax.set_xscale('log', base=10)




plot('SSB-sf100', 'SSB', 'false', 'Uniform', ax1)
plot('SSB-sf100', 'SSB', 'true', 'Prefix', ax2)
plt.subplots_adjust(hspace=0.6, wspace=0.2)

handles, labels = ax1.get_legend_handles_labels()
lgd=fig.legend(handles, labels, ncol=6, loc='upper center', fontsize=14, bbox_to_anchor=(0.5, -0.01))
plt.savefig('figs/tods23/ipf-errhist-qsize.pdf', bbox_extra_artists=[lgd], bbox_inches = 'tight', pad_inches=0.01)
# plt.show()