//
// Created by Sachin Basil John on 04.11.22.
//

#ifndef SUDOKUBECBACKEND_MYCUDAHEADERS_H
#define SUDOKUBECBACKEND_MYCUDAHEADERS_H

//#ifndef __CUDACC
//#include "cuda.h"
//#include "device_types.h"
//#include "host_defines.h"
//#include "cuda_runtime.h"
//#include "cuda_runtime_api.h"
//#include "device_launch_parameters.h"
//#include "crt/host_defines.h"
//#endif

#endif //SUDOKUBECBACKEND_MYCUDAHEADERS_H
