#!/bin/bash

# Generate base data 
bash jobs/base

#Generate datacubes
bash jobs/cube

#Run experiments
bash jobs/expts

#Plot graphs
plot-scripts/plotAll.sh