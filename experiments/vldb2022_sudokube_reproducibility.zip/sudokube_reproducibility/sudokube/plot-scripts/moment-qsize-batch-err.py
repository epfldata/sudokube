#!/usr/bin/env python3 

import csv
import sys
import matplotlib.pyplot as plt
from collections import defaultdict
from textwrap import wrap
from math import sqrt
import numpy as np

plt.rcParams["figure.figsize"] = (8,6)
plt.style.use('classic')
fig, (ax1,ax2) = plt.subplots(2,1,figsize = (8,4))
ax1.grid(which='major', axis='y',linestyle='dotted',zorder=0)
ax2.grid(which='major', axis='y',linestyle='dotted',zorder=0)

def plot(input, MS, ax):
	filename = input[8:-4]
	print(filename)

	def mean(x):
	    return sum(x) / len(x)

	errors = defaultdict(lambda: [])
	

	title="SSB " + MS + ' $n=2^{15}\\ d_{\\min}=14$'

	with open(input) as fh:
		header = [h.strip() for h in fh.readline().split(',')]
		reader = csv.DictReader(fh, fieldnames=header)
		data = list(reader)
		timescale=1000.0 * 1000.0
		for row in data:
			key = int(row['QSize'])
			err = float(row['MErr'])
			
			errors[key].append(err)
			
	keys = sorted(errors.keys())
	
	maxX = max(max(errors.values()))
	for s in sorted(errors.items(), key=lambda kv: kv[0]):
		maxv = max(s[1])
		values, base = np.histogram(s[1], bins=10, range=(0.0, maxv+0.00001))
		total = sum(values)
		cumulative = map(lambda x: float(x)/total, np.insert(np.cumsum(values),0,0))
		ax.plot(list(base), list(cumulative), label=s[0],zorder=3)
	ax.set_ylabel('RCF')
	ax.set_xlim([-maxX/12.0, maxX])
	ax.title.set_text(title)
	ax.set_xlabel('Error')
	
plot('expdata/query-dim-rms3_newmoment-batch_final.csv', 'Randomized MS', ax1)
plot('expdata/query-dim-sms3_newmoment-batch_final.csv', 'Schema-based MS', ax2)

plt.subplots_adjust(bottom=0.24,hspace=0.8)

handles, labels = ax2.get_legend_handles_labels()
lgd=fig.legend(handles, labels, ncol=4, loc='lower center', fontsize=14, bbox_to_anchor=(0.5,0.01), columnspacing=4)
plt.savefig('figs/moment-qsize-batch-err.pdf', bbox_extra_artists=[lgd],  pad_inches=0.01)