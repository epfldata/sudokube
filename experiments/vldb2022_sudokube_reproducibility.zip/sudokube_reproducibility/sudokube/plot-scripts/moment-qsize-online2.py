#!/usr/bin/env python3

import sys
import matplotlib.pyplot as plt
from collections import defaultdict
from textwrap import wrap
import numpy as np

plt.rcParams["figure.figsize"] = (8,6)
fig, (ax1,ax2) = plt.subplots(2,1)

def plot(input, MS, ax):
    filename = input[8:-4]
    isEntropy = filename.endswith('ENTROPY')
    print(filename)

    alldata = list(open(input))
    numseries = int(len(alldata)/2)
    series = []

    
    title="SSB " + MS + ' $n=2^{15}\\ d_{\\min}=14$'

    for i in range(0, numseries):
        time = map(lambda x: float(x), alldata[2*i].split(',')[1:])
        data0 = alldata[2*i + 1].split(',')
        name = data0[0]
        data = map(lambda x: float(x), data0[1:])
        series.append([time, data, name])


    for s in sorted(series, key=lambda tdn: int(tdn[2])):
        ax.plot(list(s[0]), list(s[1]), label=s[2])
    ax.title.set_text(title)
    ax.set_ylabel('Entropy' if isEntropy==1 else 'Degrees of Freedom')
    ax.set_xscale('log')

plot('expdata/query-dim-rms_newmoment-online_final-ENTROPY.csv', 'Randomized MS', ax1)
plot('expdata/query-dim-sms_newmoment-online_final-ENTROPY.csv','Schema-based MS', ax2)

plt.subplots_adjust(bottom=0.2,hspace=0.4)
plt.xlabel('Time(s)')
handles, labels = ax2.get_legend_handles_labels()
lgd=fig.legend(handles, labels, ncol=4, loc='upper center', fontsize=18, bbox_to_anchor=(0.5,0.1))
plt.savefig('figs/newmoment-qsize-online2.pdf',bbox_extra_artists=[lgd])
