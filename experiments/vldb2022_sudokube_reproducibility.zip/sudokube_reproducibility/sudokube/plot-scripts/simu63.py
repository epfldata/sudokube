#!/usr/bin/env python3 
import csv
import sys
import matplotlib.pyplot as plt
from collections import defaultdict
from textwrap import wrap
import numpy as np

input = 'expdata/simu63b.txt'
plt.style.use('classic')
series=defaultdict(lambda: [])

with open(input) as fh:
    reader = csv.reader(fh, delimiter=' ')
    data = list(reader)
    for row in data:
        key=int(row[1]) #d0
        x = int(row[0]) #d
        y = float(row[3]) #frac
        series[key].append([x,y])


fig, ax = plt.subplots(figsize=(10,2))
ax.grid(which='major', axis='y',linestyle='dotted',zorder=0)

for s in sorted(series.items(), key=lambda kv: int(kv[0])):

    sXY = sorted(s[1], key=lambda xy: xy[0])
    X = np.insert(list(map(lambda xy: xy[0], sXY)),0, s[0])
    Y = np.insert(list(map(lambda xy: xy[1], sXY)),0, 1.0)
    #print("key = ", s[0], "X=", X, "Y=", map(lambda f: int(f*100)/100.0, Y))
    if(s[0] > 5):
        ax.plot(X, Y, label=s[0], zorder=3)
    
ax.set_xlabel('Total number of dimensions d')
ax.set_ylabel('Density')
plt.xticks(np.arange(6, 31, 2.0))
plt.xlim([6, 31])
plt.savefig('figs/simu63.pdf',bbox_inches = 'tight',pad_inches = 0.01)
