#!/usr/bin/env python3
import csv
import sys
import matplotlib.pyplot as plt
from collections import defaultdict
from textwrap import wrap
import numpy as np

plt.style.use('classic')
input = sys.argv[1]
filename = input[8:-4]
isError = True
print(filename)
keyid = int(sys.argv[2])
def mean(x):
    return sum(x) / len(x)

errors = defaultdict(lambda: defaultdict(lambda: []))

with open(input) as fh:
    header = [h.strip() for h in fh.readline().split(',')]
    reader = csv.DictReader(fh, fieldnames=header)
    data = list(reader)
    for row in data:
        key0 = float(row['CubeName'].split('_')[keyid])
        key = int(key0) if (keyid==1) else key0
        counter= int(row['Counter'])
        err = float(row['Error'])
        errors[key][counter].append(err)
            
keys = sorted(errors.keys())
def func(errc):
    return map(lambda kv: [kv[0], mean(kv[1])], errc.items())

avgerrors = dict(map(lambda kv: (kv[0], func(kv[1])), errors.items()))

fig, ax = plt.subplots(figsize=(8,3))
ax.grid(which='major', axis='y',linestyle='dotted',zorder=0)
for s in sorted(avgerrors.items(), key=lambda kv: kv[0]):
    ss = sorted(s[1], key=lambda kv: kv[0])
    X = map(lambda kv: kv[0], ss)
    Y = map(lambda kv: kv[1], ss)
    ax.plot(list(X), list(Y), label=s[0],zorder=3)

plt.subplots_adjust(bottom=0.3)
ax.set_ylim([0, 0.6])
ax.set_xlabel('Number of Cuboids fetched')
ax.set_ylabel('Error' if isError==1 else 'Degrees of Freedom')
lgd=plt.legend(fontsize=12)
expname = filename.split('_')[0]
plt.savefig('figs/'+expname+'.pdf',bbox_extra_artists=[lgd], bbox_layout='tight', pad_inches = 0.01)
