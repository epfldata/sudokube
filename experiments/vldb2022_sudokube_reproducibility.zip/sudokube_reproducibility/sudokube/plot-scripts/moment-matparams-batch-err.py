#!/usr/bin/env python3 

import csv
import sys
import matplotlib.pyplot as plt
from collections import defaultdict
from textwrap import wrap
from math import sqrt
import numpy as np


plt.style.use('classic')
fig, (ax1,ax2) = plt.subplots(2,1,figsize=(8,5))
ax1.grid(which='major', axis='y',linestyle='dotted',zorder=0)
ax2.grid(which='major', axis='y',linestyle='dotted',zorder=0)

def plot(input, MS, ax):

	filename = input[8:-4]
	print(filename)

	def mean(x):
	    return sum(x) / len(x)

	errors = defaultdict(lambda: [])
	title = 'NYC ' + MS 

	with open(input) as fh:
		header = [h.strip() for h in fh.readline().split(',')]
		reader = csv.DictReader(fh, fieldnames=header)
		data = list(reader)
		timescale=1000.0*1000.0
		for row in data:
			keyfull = row['CubeName'].split('_')

			key = (int(keyfull[2]), int(keyfull[3]), int(keyfull[4]))
				
			err = float(row['MErr'])
		
			errors[key].append(err)
			
	

	maxX = max(max(errors.values()))
	for s in sorted(errors.items(), key=lambda kv: kv[0][1]*100 + kv[0][0]):
		maxv = max(s[1])
		values, base = np.histogram(s[1], bins=10, range=(0.0, maxv+0.00001))
		total = sum(values)
		cumulative = map(lambda x: float(x)/total, np.insert(np.cumsum(values),0,0))
		label = '$(' + str(s[0][1]) +',\\ 2^{' + str(s[0][0])+'})$'
		ax.plot(list(base), list(cumulative), label=label,zorder=3)
	ax.set_ylabel('RCF')
	ax.set_xlim([-maxX/12.0, maxX])
	ax.title.set_text(title)
	ax.set_xlabel('Error')

plot('expdata/mat-params-rms3_newmoment-batch_final.csv', 'Randomized MS', ax1)
plot('expdata/mat-params-sms3_newmoment-batch_final.csv', 'Schema-based MS', ax2)


plt.subplots_adjust(bottom=0.3,hspace=0.6)

handles, labels = ax2.get_legend_handles_labels()
lgd=fig.legend(handles, labels, ncol=3, loc='lower center', fontsize=16, bbox_to_anchor=(0.5,0.01),columnspacing=4,labelspacing=0.4)
plt.savefig('figs/moment-matparams-batch-err.pdf',bbox_extra_artists=[lgd],pad_inches=0.01)