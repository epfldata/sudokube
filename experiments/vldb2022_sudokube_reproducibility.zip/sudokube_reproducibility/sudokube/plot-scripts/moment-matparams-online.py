#!/usr/bin/env python3 

import sys
import matplotlib.pyplot as plt
from collections import defaultdict
from textwrap import wrap
import numpy as np

plt.style.use('classic')
fig, (ax1,ax2) = plt.subplots(2,1,figsize=(8,5))
ax1.grid(which='major', axis='y',linestyle='dotted',zorder=0)
ax2.grid(which='major', axis='y',linestyle='dotted',zorder=0)

def plot(input, title, ax, islog):
    filename = input[8:-4]
    isError = filename.endswith('ERROR')
    print(filename)

    alldata = list(open(input))
    numseries = int(len(alldata)/2)
    series = []
    for i in range(0, numseries):
        time = map(lambda x: float(x), alldata[2*i].split(',')[1:])
        data0 = alldata[2*i + 1].split(',')
        name0 = data0[0].split('_')
        name = [int(name0[2]), int(name0[3]), int(name0[4])]
        data = map(lambda x: float(x), data0[1:])
        series.append([time, data, name])


    ss = sorted(series, key=lambda tdn: tdn[2][1]*100 + tdn[2][0])
    for s in ss:
        label = '$(' + str(s[2][1]) + ',\\ 2^{' + str(s[2][0])+'})$'
        ax.plot(list(s[0]), list(s[1]), label=label,zorder=3)

    ax.set_ylabel('Error' if isError==1 else 'Degrees of Freedom')
    if(islog):
        ax.set_yscale('log')
    ax.set_xscale('log')
    ax.set_ylim([0.001, 1])
    ax.title.set_text(title)
    ax.set_xlabel('Time(s)')

plot('expdata/mat-params-rms3_newmoment-online_final-ERROR.csv', 'NYC Randomized MS', ax1, False)
plot('expdata/mat-params-sms3_newmoment-online_final-ERROR.csv', 'NYC Schema-based MS', ax2, True)

plt.subplots_adjust(bottom=0.3,hspace=0.6)

handles, labels = ax2.get_legend_handles_labels()
lgd=fig.legend(handles, labels, ncol=3, loc='lower center', fontsize=16, bbox_to_anchor=(0.5,0.01),columnspacing=4,labelspacing=0.4)
plt.savefig('figs/moment-matparams-online.pdf',bbox_extra_artists=[lgd],pad_inches=0.01)
