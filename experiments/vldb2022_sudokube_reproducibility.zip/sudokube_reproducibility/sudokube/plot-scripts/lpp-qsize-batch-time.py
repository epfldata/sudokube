#!/usr/bin/env python3 

import csv
import sys
import matplotlib.pyplot as plt
from collections import defaultdict
from textwrap import wrap
from math import sqrt
import numpy as np


plt.style.use('classic')
fig, (ax1,ax2) = plt.subplots(2,1,figsize=(8,3.3))

ax1.grid(which='major', axis='y',linestyle='dotted', zorder=0)
ax2.grid(which='major', axis='y',linestyle='dotted',zorder=0)

def plot(input,ax):
	
	filename = input[8:-4]
	print(filename)

	def mean(x):
	    return sum(x) / len(x)

	naivefetch = defaultdict(lambda: [])
	naiveprepare = defaultdict(lambda: [])

	lpp_prepare =defaultdict(lambda: [])
	lpp_fetch = defaultdict(lambda: [])
	lpp_old_solve = defaultdict(lambda: [])
	lpp_new_solve = defaultdict(lambda: [])


	with open(input) as fh:
		header = [h.strip() for h in fh.readline().split(',')]
		reader = csv.DictReader(fh, fieldnames=header)
		data = list(reader)
		timescale=1000.0*1000.0
		cname0=''
		for row in data:
			key = int(row['QSize'])
			cname0 = row['CubeName']
	
			nfetch = int(row['NFetchTime(us)'])/timescale
			nprep = int(row['NPrepareTime(us)'])/timescale
			lpprep = int(row['LPPrepareTime(us)'])/timescale
			lpfetch = int(row['LPFetchTime(us)'])/timescale
			lpsolve_new = (int(row['Init SliceSparse']) + int(row['ComputeBounds SliceSparse']))/timescale 
	
			naivefetch[key].append(nfetch)
			naiveprepare[key].append(nprep)
	
			lpp_fetch[key].append(lpfetch)
			lpp_new_solve[key].append(lpsolve_new)
			lpp_prepare[key].append(lpprep)

	cname=cname0.split('_')
	MS=("Randomized" if(cname[1].startswith('rms')) else "Schema-based")+ " MS"

	title="SSB " + MS + ' $n=2^{'+cname[2]+'}\\ d_{\\min}=' + cname[3] + '$'
	keys = sorted(naivefetch.keys())
	
	nfetch_avg = np.array(list(map(lambda x: mean(x[1]), sorted(naivefetch.items(),key = lambda kv: kv[0]))))
	nprep_avg = np.array(list(map(lambda x:  mean(x[1]), sorted(naiveprepare.items(),key = lambda kv: kv[0]))))
	lpp_prep_avg = np.array(list(map(lambda x: mean(x[1]), sorted(lpp_prepare.items(),key = lambda kv: kv[0]))))
	lpp_fetch_avg = np.array(list(map(lambda x: mean(x[1]), sorted(lpp_fetch.items(),key = lambda kv: kv[0]))))
	lpp_new_solve_avg = np.array(list(map(lambda x: mean(x[1]), sorted(lpp_new_solve.items(), key = lambda kv: kv[0]))))
	ax.title.set_text(title)
	N = len(keys)
	X = np.arange(0, N)    # set up a array of x-coordinates

	w=1.0/9
	minval = 10.0 ** -4
	ax.bar(X-3*w, nprep_avg, w, bottom = minval, label='Naive Prepare', color='limegreen',zorder=3)
	ax.bar(X+w , lpp_fetch_avg, w, bottom = minval, label='LP Fetch', color='blue',zorder=3)
	
	ax.bar(X-2*w ,nfetch_avg, w, label='Naive Fetch', bottom=minval, color='turquoise',zorder=3)
	ax.bar(X+2*w, lpp_new_solve_avg, w, bottom = minval, label='LP Solve', color='gray',zorder=3)
	
	
	ax.bar(X-w , nprep_avg+nfetch_avg, w, label='Naive Total', bottom=minval, color='tomato',zorder=3)
	ax.bar(X+3*w , lpp_prep_avg + lpp_fetch_avg + lpp_new_solve_avg, w, bottom = minval, label='LP Total', color='red',zorder=3)
	
	ax.bar(X , lpp_prep_avg , w, bottom =  minval, label='LP Prepare', color='darkgreen',zorder=3)
	
	
	ax.set_ylabel('Time(s)')
	ax.set_xticks(X)
	ax.set_xticklabels(keys)
	ax.set_yscale('log')
	for label in ax.yaxis.get_ticklabels()[::2]:
		label.set_visible(False)

	ax.set_xlim([-4*w, 3+4*w ])
	ax.set_xlabel('Query Dimensionality')

plot('expdata/query-dim-rms3_lp-batch_final.csv', ax1)
plot('expdata/query-dim-sms3_lp-batch_final.csv', ax2)

plt.subplots_adjust(bottom=0.3,hspace=1)


handles, labels = ax2.get_legend_handles_labels()
lgd=fig.legend(handles, labels, ncol=4, loc='lower center', fontsize=9, bbox_to_anchor=(0.5,0.01), columnspacing=5,labelspacing=0.3)
plt.savefig('figs/lpp-qsize-batch-time.pdf', bbox_extra_artists=[lgd],  pad_inches = 0.01)
