#!/usr/bin/env python3

import csv
import sys
import matplotlib.pyplot as plt
from collections import defaultdict
from textwrap import wrap
from math import sqrt
import numpy as np


plt.style.use('classic')
fig, (ax1,ax2) = plt.subplots(2,1,figsize = (8,4))
ax1.grid(which='major', axis='y',linestyle='dotted',zorder=0)
ax2.grid(which='major', axis='y',linestyle='dotted',zorder=0)


def plot(input, MS, ax):
	filename = input[8:-4]
	print(filename)

	def mean(x):
	    return sum(x) / len(x)

	naivefetch = defaultdict(lambda: [])
	naiveprepare = defaultdict(lambda: [])
	momentprepare =defaultdict(lambda: [])
	momentfetch = defaultdict(lambda: [])
	momentsolve = defaultdict(lambda: [])

	title="SSB " + MS + ' $n=2^{15}\\ d_{\\min}=14$'

	with open(input) as fh:
		header = [h.strip() for h in fh.readline().split(',')]
		reader = csv.DictReader(fh, fieldnames=header)
		data = list(reader)
		timescale=1000.0 * 1000.0
		for row in data:
			key = int(row['QSize'])
	
			nfetch = int(row['NFetchTime(us)'])/timescale
			nprep = int(row['NPrepareTime(us)'])/timescale
			mprep = int(row['MPrepareTime(us)'])/timescale
			mfetch = int(row['MFetchTime(us)'])/timescale
			msolve = int(row['MSolveTime(us)'])/timescale

			naivefetch[key].append(nfetch)
			naiveprepare[key].append(nprep)
			momentfetch[key].append(mfetch)
			momentsolve[key].append(msolve)
			momentprepare[key].append(mprep)

	keys = sorted(naivefetch.keys())
	
	nfetch_avg = np.array(list(map(lambda x: mean(x[1]), sorted(naivefetch.items(),key = lambda kv: kv[0]))))
	nprep_avg = np.array(list(map(lambda x:  mean(x[1]), sorted(naiveprepare.items(),key = lambda kv: kv[0]))))
	mprep_avg = np.array(list(map(lambda x: mean(x[1]), sorted(momentprepare.items(),key = lambda kv: kv[0]))))
	mfetch_avg = np.array(list(map(lambda x: mean(x[1]), sorted(momentfetch.items(),key = lambda kv: kv[0]))))
	msolve_avg = np.array(list(map(lambda x: mean(x[1]), sorted(momentsolve.items(), key = lambda kv: kv[0]))))


	N = len(keys)
	X = np.arange(0, N)    # set up a array of x-coordinates
	w=1.0/9

	minval = 10.0 ** -4
	ax.bar(X-3*w , nprep_avg , bottom = minval, width=w,label='Naive Prepare', color='limegreen',zorder=3)
	ax.bar(X , mprep_avg, bottom=minval, width=w, label='Moment Prepare', color='darkgreen',zorder=3)
	
	ax.bar(X+3*w , mprep_avg+mfetch_avg+msolve_avg, width=w, bottom=minval, label='Moment Total', color='red',zorder=3)
	
	ax.bar(X-2*w , nfetch_avg, bottom = minval, width=w,label='Naive Fetch', color='turquoise',zorder=3)
	ax.bar(X+w , mfetch_avg, bottom=minval, width=w, label='Moment Fetch', color='blue',zorder=3)
	
	ax.bar(X-w , nprep_avg + nfetch_avg, bottom = minval, width=w,label='Naive Total', color='tomato',zorder=3)
	ax.bar(X+2*w , msolve_avg, bottom=minval, width=w, label='Moment Solve', color='gray',zorder=3)

	
	
	ax.set_ylabel('Time(s)')
	ax.set_xticks(X)
	ax.set_xticklabels(keys)
	
	ax.set_yscale('log')
	for label in ax.yaxis.get_ticklabels()[::2]:
		label.set_visible(False)
	ax.title.set_text(title)
	ax.set_xlim([-4*w, 3+4*w ])
	ax.set_xlabel('Query Dimensionality')

plot('expdata/query-dim-rms3_newmoment-batch_final.csv', 'Randomized MS', ax1)
plot('expdata/query-dim-sms3_newmoment-batch_final.csv', 'Schema-based MS', ax2)

plt.subplots_adjust(bottom=0.33,hspace=1)

handles, labels = ax2.get_legend_handles_labels()
lgd=fig.legend(handles, labels, ncol=3, loc='lower center', fontsize=11, bbox_to_anchor=(0.5,0.01), columnspacing=4, labelspacing=0.3)
plt.savefig('figs/moment-qsize-batch-time.pdf',bbox_extra_artists=[lgd],pad_inches=0.01)