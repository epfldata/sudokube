#!/usr/bin/env python3

import sys
import matplotlib.pyplot as plt
from collections import defaultdict
from textwrap import wrap
import numpy as np


plt.style.use('classic')

def plot(input, title, ax, uselog):
    filename = input[8:-4]
    isError = filename.endswith('ERROR')
    print(filename)

    alldata = list(open(input))
    numseries = int(len(alldata)/2)
    series = []

    

    for i in range(0, numseries):
        time = map(lambda x: float(x), alldata[2*i].split(',')[1:])
        data0 = alldata[2*i + 1].split(',')
        name = data0[0]
        data = map(lambda x: float(x), data0[1:])
        series.append([time, data, name])


    for s in sorted(series, key=lambda tdn: tdn[2]):
        ax.plot(list(s[0]), list(s[1]), label=s[2],zorder=3)
    ax.title.set_text(title)
    ax.set_ylabel('Error' if isError==1 else 'Degrees of Freedom')
    if(uselog):
        ax.set_ylim(bottom=0.001)
        ax.set_xscale('log')
        ax.set_yscale('log')
    ax.legend(loc='upper left', fontsize=10, bbox_to_anchor=(1,1))
    ax.set_xlabel('Time(s)')

fig, (ax1, ax2) = plt.subplots(2,1,figsize=(12,4))
plot('expdata/manual-ssb-sms3_newmoment-online_final-ERROR.csv','SSB Schema-based MS $n=2^{15}\\ d_{\\min}=14$', ax1, True)
ax1.grid(which='major', axis='y',linestyle='dotted',zorder=0)
ax2.grid(which='major', axis='y',linestyle='dotted',zorder=0)

plt.subplots_adjust(hspace=0.6,right=0.6, bottom=0.15)

#handles, labels = ax2.get_legend_handles_labels()
#lgd=fig.legend(handles, labels, ncol=4, loc='upper center', fontsize=10, bbox_to_anchor=(0.5,0.1))
#plt.savefig('figs/manual-SSB-online.pdf',bbox_extra_artists=[lgd], bbox_inches = 'tight')

#fig, ax2 = plt.subplots(1,1)
plot('expdata/manual-nyc-sms3_newmoment-online_final-ERROR.csv','NYC Schema-based MS $n=2^{15}\\ d_{\\min}=14$', ax2, False)

#plt.subplots_adjust(bottom=0.2,hspace=0.4)
#plt.xlabel('Time(s)')
#handles, labels = ax2.get_legend_handles_labels()
#lgd=fig.legend(handles, labels, ncol=4, loc='upper center', fontsize=10, bbox_to_anchor=(0.5,0.1))
plt.savefig('figs/manual-online.pdf')
