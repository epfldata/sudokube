#!/bin/bash

#Simulation (Fig 1)
#plot-scripts/simu63.py

#Distribution of cuboids (Fig 7)
plot-scripts/cuboid-distr.py


#LP Solver QSize Batch (Fig 8)
plot-scripts/lpp-qsize-batch-time.py 

#------

#Moment Solver QSize Online (Fig 9a)
sbt --error 'set showSuccess := false' "runMain experiments.plotters.OnlinePlotter query-dim-rms3_newmoment-online_final.csv qsize"
sbt --error 'set showSuccess := false' "runMain experiments.plotters.OnlinePlotter query-dim-sms3_newmoment-online_final.csv qsize"
plot-scripts/moment-qsize-online.py


#Moment Solver QSize Batch  (Fig 9bc)
plot-scripts/moment-qsize-batch-time.py
plot-scripts/moment-qsize-batch-err.py

#-------------

#Moment Solver Materialization Parameters Online (Fig 10a)

sbt --error 'set showSuccess := false' "runMain experiments.plotters.OnlinePlotter mat-params-rms3_newmoment-online_final.csv params"
sbt --error 'set showSuccess := false' "runMain experiments.plotters.OnlinePlotter mat-params-sms3_newmoment-online_final.csv params"
plot-scripts/moment-matparams-online.py 

plot-scripts/moment-matparams-batch-time.py
plot-scripts/moment-matparams-batch-err.py

#-------

#Microbench (Fig 11)
plot-scripts/microbench-online.py expdata/mb-dims_newmoment-online_final.csv 1
plot-scripts/microbench-online.py expdata/mb-stddev_newmoment-online_final.csv 3
plot-scripts/microbench-online.py expdata/mb-prob_newmoment-online_final.csv 4

#
sbt --error 'set showSuccess := false' "runMain experiments.plotters.OnlinePlotter manual-ssb-sms3_newmoment-online_final.csv query"
sbt --error 'set showSuccess := false' "runMain experiments.plotters.OnlinePlotter manual-nyc-sms3_newmoment-online_final.csv query"

plot-scripts/manual-online.py 

