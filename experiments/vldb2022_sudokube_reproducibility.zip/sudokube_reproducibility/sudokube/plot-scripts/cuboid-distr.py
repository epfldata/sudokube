#!/usr/bin/env python3 

import sys
import matplotlib.pyplot as plt
from collections import defaultdict
from textwrap import wrap
import numpy as np

plt.style.use('classic')
fig, (ax1,ax2) = plt.subplots(1,2, figsize=(8,3))
ax1.grid(which='major', axis='y',linestyle='dotted',zorder=0)
ax2.grid(which='major', axis='y',linestyle='dotted',zorder=0)
ax1.set_ylim(top=10.0**32)


def plot(input, title, ax):
    filename = input[8:-4]
    print(filename)

    
    alldata = list(open(input))
    numseries = len(alldata)
    series = []


    for i in range(0, numseries):
        data0 = alldata[i].split(',')
        name = data0[0]
        data = list(map(lambda x: float(x), data0[1:]))
        series.append([name, data])


    header = series[0]
    total = series[-1]
    def nanify(vs):
        return [float('nan') if x==0 else x for x in vs]
    def split(x): 
        params = x[0].split('_')
        return ((int(params[0]), int(params[1])), x[1])
    ss= sorted(map(split, series[1:-1]), key=lambda kv:kv[0][1]*100 + kv[0][0])
    for s in ss:
        label = '$d_{\\min}=' + str(s[0][1]) + ',\\ n=2^{' + str(s[0][0])+'}$'
        ax.plot(header[1], nanify(s[1]), label=label,zorder=3)
    ax.plot(header[1], total[1], label='All possible cuboids', color='black', ls='dashed', zorder=3)
    ax.title.set_text(title)    
    ax.set_yscale('log')
    ax.set_ylim(bottom=1)
    ax.set_xlim(left=0, right=30)
    ax.set_xlabel('#Dimensions')
    ax.set_ylabel('#Cuboids')

plot('expdata/Cuboids_NYC_rms3.csv', 'Randomized MS', ax1)
plot('expdata/Cuboids_NYC_sms3.csv', 'Schema-based MS', ax2)
plt.subplots_adjust(right=0.7,wspace=0.4)


handles, labels = ax2.get_legend_handles_labels()
lgd=fig.legend(handles, labels, ncol=1, loc='center left', fontsize=11, bbox_to_anchor=(0.7,0.5),labelspacing=1.3)
plt.savefig('figs/NYC_cuboids.pdf',bbox_extra_artists=[lgd],pad_inches=0.01)
