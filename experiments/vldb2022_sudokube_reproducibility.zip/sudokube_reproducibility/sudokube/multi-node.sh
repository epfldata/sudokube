#!/bin/bash

hosts=`cat hosts | xargs`
hostsWithCores=`echo $hosts | xargs -n1 printf "1/%s,"`

echo "HOSTS=$hosts"

# Generate base data 
parallel --env PATH -S $hostsWithCores --wd /app/sudokube --tag --lb -a jobs/base
bash syncFolder.sh "$hosts" tabledata
bash syncFolder.sh "$hosts" cubedata

#Generate datacubes
parallel --env PATH  -S $hostsWithCores --wd /app/sudokube  --tag --lb -a jobs/cube
bash syncFolder.sh "$hosts" cubedata

#Run experiments
parallel --env PATH  -S $hostsWithCores --wd /app/sudokube  --tag --lb -a jobs/expts
bash syncFolder.sh "$hosts" expdata

#Plot graphs
plot-scripts/plotAll.sh