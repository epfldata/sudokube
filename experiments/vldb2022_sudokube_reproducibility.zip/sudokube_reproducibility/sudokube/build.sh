docker build -t sudokube .
