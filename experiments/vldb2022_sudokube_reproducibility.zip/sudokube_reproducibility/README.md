# Readme for reproducibility for Sudokube

## A) Source code info
Source code included in package under folder `sudokube`.
- Programming Language: mostly Scala
- Packages/Libraries Needed: Docker (see included Dockerfile)

## B) Datasets info
We use two datasets in our experiments.
1. [New York Parking Violations Dataset](https://data.cityofnewyork.us/City-Government/Parking-Violations-Issued-Fiscal-Year-2021/kvfd-bves)
2. [Star Schema Benchmark](https://github.com/eyalroz/ssb-dbgen)
   The scripts for downloading/generating data are included in this package.


## C) Hardware Info

### C1) Processor (architecture, type, and number of processors/sockets)
Dual-socket Intel® Xeon® CPU E5-2680 v3 2.50GHz (2 x 12 physical cores)

### C2) Memory (size and speed)
256 GB DDR4 - 2133 MHz

### C3) Secondary Storage (type: SSD/HDD/other, size, performance: random read/sequnetial read/random write/sequnetial write)
At least 200 GB to store all the data. Exact specifications don't matter as our experiments are in-memory.

### C4) Network (if applicable: type and bandwidth)
N/A


# D) Experimentation Info


All experiments are packaged inside a Docker container. As a prerequisite, you need to install Docker. Here is the detailed instructions for installing Docker on your platform: https://docs.docker.com/engine/installation.

For ease of use, simple `build.sh` and `run.sh` scripts are provided which build and run the Docker container respectively.

The root scripts directory is /app/sudokube (within the Docker container).
* Scripts for data loading are in the folder `dataloading-scripts`
* Experiments are run using `sbt` with main class `experiments.Experimenter` and passing the name of the experiment as argument.
* Scripts for plotting the experiment results are in the folder `plot-scripts`

In order to reproduce the experiment with fixed queries (Fig 12) exactly, we have fixed the seed of the random generator
that is used in deciding what cuboids are materialized to zero. This can be disabled by editing the files `src/main/scala/frontend/generators/NYC.scala` and  `src/main/scala/frontend/generators/SSB.scala` before generating the data cube.

All of our experiments require only a single node to run.  The script `single-node.sh` runs experiments sequentially one after the other on the same node. However, this may take very long (more than 7 days).
Therefore, we provide the script `multi-node.sh` to run several experiments in parallel on different nodes.

## Single-node execution
- Step 1: add your user to the "sudo" and "docker" groups.
  In Ubuntu, you can run `sudo usermod -aG sudo YOUR_USER_NAME && sudo usermod -aG docker YOUR_USER_NAME`.

- Step 2: execute `bash build.sh` script once to build the Docker image.

- Step 3: execute `bash run.sh` as root to run the previously built Docker image. After this step you automatically enter the docker instance and the current directory should be `/app/sudokube`.

- Step 4: execute `bash single-node.sh` to run all experiments inside the docker container.

##  Multi-node execution
Repeat the steps on all nodes. The recommended number is 5 or 6 nodes.
- Step 0: Edit `hosts` file in the package to store the names/IP addresses of all the hosts (one per line).
- Step 1: add your user to the "sudo" and "docker" groups.
  In Ubuntu, you can run `sudo usermod -aG sudo YOUR_USER_NAME && sudo usermod -aG docker YOUR_USER_NAME`.
- Step 2: execute `bash build.sh` script once to build the Docker image.

- Step 3a: execute `bash run-slave.sh` as root on all nodes **except the first node**.
- Step 3b: execute `bash run.sh` as root on **only the first node** to run the previously built Docker image. After this step you automatically enter the docker instance and the current directory should be `/app/sudokube`.

The last step is to be run on **only on the first container** after all containers are initialized.

- Step 4: execute `bash multi-node.sh` to run all experiments inside docker containers coordinated by this container.

## Output
There are four output directories in the root folder `/app/sudokube` which are also mapped to folders with the same names in the host file system
- tabledata: contains the raw datasets along with files storing distinct values in each column.
- cubedata: contains the binary files serializing the data cubes.
- expdata: contains the results of the experiments in csv or tex format.
- figs: contains the output PDF files for each figure using experiment results

You can find the relevant files for each of the results as the following
- Figure 7: `figs/NYC_cuboids.pdf`
- Table 1 (Latex): `expdata/storage_overhead.tex`
- Figure 8: `figs/lpp-qsize-batch-time.pdf`
- Figure 9a: `figs/moment-qsize-online.pdf`
- Figure 9b: `figs/moment-qsize-batch-time.pdf`
- Figure 9c: `figs/moment-qsize-batch-err.pdf`
- Figure 10a: `figs/moment-matparams-online.pdf`
- Figure 10b: `figs/moment-matparams-batch-time.pdf`
- Figure 10c: `figs/moment-matparams-batch-err.pdf`
- Figure 11a: `figs/mb-dims.pdf`
- Figure 11b: `figs/mb-stddev.pdf`
- Figure 11c: `figs/mb-prob.pdf`
- Figure 12: `figs/manual-online.pdf`
