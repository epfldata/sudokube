#!/bin/bash

cur=`pwd`
docker run -p 2222:2222 \
		   -v $cur/cubedata:/app/sudokube/cubedata \
		   -v $cur/tabledata:/app/sudokube/tabledata \
		   -v $cur/expdata:/app/sudokube/expdata \
		   -v $cur/figs:/app/sudokube/figs \
		   -it sudokube /bin/bash -c "/usr/sbin/sshd && /bin/bash"
